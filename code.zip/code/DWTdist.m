function [dist] = DWTdist(t,List_r)

dist = zeros(size(List_r,1),1);


for x = 1:1:size(List_r,1)
    x
    
 r = List_r{x};
 % frame number
 n = size(t,1);
 m = size(r,1);
 if mod(n,2) == 1
     flag = 1;
 else
     flag = 0;
 end
 % Frame matching distance matrix
 d = zeros(n,m);
 if flag == 1
      for i = 1:(n+1)/2
        for j = 1:2*(i-1)
            d(i,j) = (t(i)-r(j)).^2;
        end
      end
 else
 end
 
d = d/max(max(d));
% Cumulative distance matrix
D = ones(n,m) *realmax;
D(1,1) = d(1,1);
% DTW
for i = 2:1:n
    
    D(i,1) = d(i,1) + D(i-1,j);
    D(i,2) = d(i,2) + min([D(i-1,j),D(i-1,j-1)]);
    
    for j = 3:1:m
        D1 = D(i-1,j);
        D2 = D(i-1,j-1);
        D3 = D(i-1,j-2);
        D(i,j) = d(i,j) + min([D1,D2,D3]);
    end
    
end
%mesh(D);
dist(x) = D(n,m);
end