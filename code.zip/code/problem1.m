%'data\problem1\ref'
clear;

RefDir = 'data\problem1\ref\';
ref = cell(9,1);
state = cell(9,1);
for i = 1:1:9
    filePath = [RefDir, num2str(i),'.wav'];
    [temp,FS] = audioread(filePath);
    temp = temp/max(temp);
    temp = cutoff(temp,FS);
    ref{i} = temp;
end

testDir = 'data\problem1\test\';
fileFolder=fullfile(testDir);
dirOutput=dir(fullfile(fileFolder,'*.wav'));
fileNames={dirOutput.name}';

%for i = 1:1:size(fileNames,1)
for i = 1:1:1
    fileName = fileNames{i};
    filePath = [testDir, fileName];
    [signal,FS] = audioread(filePath);
    signal = cutoff(signal,FS);
    dist = DWTdist(signal,ref);
    
    [minD,N] = min(dist);
    disp([fileName,' is ', num2str(N)]);
end