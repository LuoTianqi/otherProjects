function [v] = decide_V(frameSignal)
amp1 = 0.05;

zcr = 0.15;

voiced = 1;
unvoiced = 1;
silence = 0;
E = 0;
Z = 0;
frameLength = length(frameSignal);
    for j = 1:frameLength;%����ÿһ֡������
        E = E+frameSignal(j)^2;
        if j < frameLength
            Z = Z + abs(sign(frameSignal(j))-sign(frameSignal(j+1)));
        end
    end
    Z = Z/2/frameLength;

    if E < amp1
        v = silence;
    elseif (Z-E) > 0.1
        v = unvoiced;
    else 
        v = voiced;
    end