function [output] = cutoff(input,FS)
L = 25*0.001*FS;
R = 10*0.001*FS;
N = length(input);
order = 10;
output = [];

n = 1; nframes = 0;
V = zeros(size(input));
while n+L-1 <= length(input)
    x=input(n:n+L-1);
    [b0,a,pitch,v,E,Z] = LPCSR_Analysis(x,FS,L,order);
    V(n:n+L-1) = ones(L,1)*v;
    n=n+R;                            
    nframes=nframes+1;
end

V = smooth(V,1000);


for i = 1:1:length(V)
    if V(i) <= 0.2
        V(i) = 0;
    else
        V(i) = 1;
        output = [output;input(i)];
        count = i;
    end
end

for i = (count+1):1:(count + 201)
    V(i) = 1;
    output = [output;input(i)];
end

% 
% figure;
% plot(V);
% hold on
% plot(input);